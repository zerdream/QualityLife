package yinao.qualityLife.model;

public interface LoginDetail {

    String getUsername();
    String getPassword();
    boolean enable();
}
